//////////////////////////////////////////////////////////////////////////////////
// This is a front end for a set of viewer clases for the Carnegie Mellon
// Motion Capture Database: 
//    
//    http://mocap.cs.cmu.edu/
//
// The original viewer code was downloaded from:
//
//   http://graphics.cs.cmu.edu/software/mocapPlayer.zip
//
// where it is credited to James McCann (Adobe), Jernej Barbic (USC),
// and Yili Zhao (USC). There are also comments in it that suggest
// and Alla Safonova (UPenn) and Kiran Bhat (ILM) also had a hand in writing it.
//
//////////////////////////////////////////////////////////////////////////////////
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <float.h>
#include "SETTINGS.h"
#include "skeleton.h"
#include "displaySkeleton.h"
#include "motion.h"

#define PI 3.141592653589793238


using namespace std;

// Stick-man classes
DisplaySkeleton displayer;    
Skeleton* skeleton;
Motion* motion;

int windowWidth = 640;
int windowHeight = 480;

// int windowWidth = 1280;
// int windowHeight = 960;

// VEC3 eye(-6, 0.5, 1); //looking slanted at person but with the funky coordinates
// VEC3 eye(0.0, 0.5, -7); // looking at right wall but with the funky coordinates
// VEC3 lookingAt(5, 0.5, 1); //looking at person? but wiht the funky coordinatess

// VEC3 eye(-5, 0.5, 3); //right in front of person straight onnnn- where should end up somewhere in scene


VEC3 eye(0, 0.5, -5); //looks down z-axis

VEC3 lookingAt(0,0.5,3); // looks at person straight on

VEC3 up(0,1,0);

// scene geometry

vector<bool> mirror;
vector<bool> reflection;
vector<bool> refraction;
// vector<bool> triangle;
vector<VEC3> vertex1;
vector<VEC3> vertex2;
vector<VEC3> vertex3;

vector<bool> shape;
vector<bool> triangle;
vector<bool> cylinder;
vector<bool> sphere;

vector<VEC3> cylinderCenters;
vector<float> radiusCylinder;
vector<MATRIX4> cylinderRotation;
vector<VEC3> cylinderColors;
vector<float> top;
vector<float> bottom;

vector<VEC3> triangleVertex1;
vector<VEC3> triangleVertex2;
vector<VEC3> triangleVertex3;
vector<VEC3> triangleColors;

vector<VEC3> sphereCenters;
vector<float> sphereRadii;
vector<VEC3> sphereColors;

vector<bool> poleflag;

vector<VEC3> lightposition;
vector<VEC3> lightcolor;

// vector<VEC3> glossyreflection;





//   typedef struct{ 
//   VEC3 center;
//   int radius;
//   VEC3 color;
//   bool mirror;
//   bool refraction;
//   bool triangle; 
//   VEC3 vertex1;
//   VEC3 vertex2;
//   VEC3 vertex3; 
// } sphere;

typedef struct{ 
  VEC3 position;
  VEC3 color;
} light;

double E = 0.01;

VEC3 truncate(const VEC4& v)
{
  return VEC3(v[0], v[1], v[2]);
}
VEC4 extend(const VEC3& v)
{
  return VEC4(v[0], v[1], v[2], 1.0);
}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
void writePPM(const string& filename, int& xRes, int& yRes, const float* values)
{
  int totalCells = xRes * yRes;
  unsigned char* pixels = new unsigned char[3 * totalCells];
  for (int i = 0; i < 3 * totalCells; i++)
    pixels[i] = values[i];

  FILE *fp;
  fp = fopen(filename.c_str(), "wb");
  if (fp == NULL)
  {
    cout << " Could not open file \"" << filename.c_str() << "\" for writing." << endl;
    cout << " Make sure you're not trying to write from a weird location or with a " << endl;
    cout << " strange filename. Bailing ... " << endl;
    exit(0);
  }

  fprintf(fp, "P6\n%d %d\n255\n", xRes, yRes);
  fwrite(pixels, 1, totalCells * 3, fp);
  fclose(fp);
  delete[] pixels;
}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
bool raySphereIntersect(const VEC3& center, 
                        const float radius, 
                        const VEC3& rayPos, 
                        const VEC3& rayDir,
                        float& t)
{
  const VEC3 op = center - rayPos;
  const float eps = 1e-8;
  const float b = op.dot(rayDir);
  float det = b * b - op.dot(op) + radius * radius;

  // o_cylinder = 

  // determinant check
  if (det < 0) 
    return false; 
  
  det = sqrt(det);
  t = b - det;
  if (t <= eps)
  {
    t = b + det;
    if (t <= eps)
      t = -1;
  }

  if (t < 0) return false;
  return true;
}

bool rayCylinderIntersect(const VEC3& center, 
                        const float radius, 
                        const MATRIX4 rotation, const float top, const float bottom,
                         const VEC3& rayPos, 
                        const VEC3& rayDir,
                        float& t, bool poleflag)
{


  VEC3 newrayPos = truncate(rotation.transpose()*extend(rayPos-center));
  VEC3 newrayDir = truncate(rotation.transpose()*extend(rayDir));

  double A = (newrayDir[0]*newrayDir[0])+(newrayDir[1]*newrayDir[1]);
  double B = (2*newrayDir[0]*newrayPos[0])+(2*newrayDir[1]*newrayPos[1]);
  double C = (newrayPos[0]*newrayPos[0])+(newrayPos[1]*newrayPos[1])-radius*radius;
  
  float checkingelement = B*B-4*A*C;
  // const VEC3 op = VEC3(0,0,0) - rayPos;
  const float eps = 1e-8;
  // const float b = op.dot(rayDir);
  // float det = b * b - op.dot(op) + radius * radius;

    // EXTEND HERE
  // o_cylinder = extend(rotation.transpose)*(e-cylinder.center());
  // d_cylinder = extend(rotation.transpose)*d_persp;


  // double A = (d[0]*d[0])+(d[1]*d[1]);
  // double B = (2*d[0]*o[0])+(2*d[1]*o[1]);
  // double C = (o[0]*o[0])+(o[1]*o[1])-0.05*0.05;

//   // truncate before returning

  if(checkingelement>=0){ //has not imaginary root
    
      double t_1 = (-B+sqrt(checkingelement))/(2*A);
      double t_2 = (-B-sqrt(checkingelement))/(2*A);

      if(t_1 > 0 && t_2 > 0){
        double minnn = min(t_1, t_2);
        // t = min(t, minnn); 
        // if(t == min(t_1, t_2)){
          if(minnn<t){
            t = minnn;
          // printf("in 1st conditional in intersect\n");
          VEC3 newcollisionpt = newrayPos + t*newrayDir;
          if(newcollisionpt[2] <= top && newcollisionpt[2]>= bottom){
            return true;
          }
          // else if(poleflag == true && newcollisionpt[1] <= top && newcollisionpt[1]>= bottom){
          //   return true;
          // }
          else{
            return false;
          }
        }

        
        

      // else if(refraction && t_1>0 && t_2<0 && t_1<t){
      //   // printf("t_1>0\n");
      //   t= t_1;
      //   sphereno = i;
      //   // return (e + t_1*d_persp);
      // }
      // else if(refraction && t_2>0 && t_1<0 && t_2<t){
      //   // printf("t_2>0\n");
      //   t= t_2;
      //   sphereno = i;
      //   // return (e + t_2*d_persp);
      // }
      // else{
      //   return VEC3(INFINITY, INFINITY, INFINITY);
      // }
    } 
  }
  return false;
    
}


bool rayTriangleIntersect( const VEC3& rayPos, const VEC3& rayDir, const VEC3& vertex1, const VEC3& vertex2, const VEC3& vertex3, float& t) {
    VEC3 a = vertex1;
      VEC3 b = vertex2;
      VEC3 c = vertex3;
      double x_a = a[0];
      double y_a = a[1];
      double z_a = a[2];

      double x_b = b[0];
      double y_b = b[1];
      double z_b = b[2];

      double x_c = c[0];
      double y_c = c[1];
      double z_c = c[2]; 

      double x_d = rayDir[0];
      double y_d = rayDir[1];
      double z_d = rayDir[2];

      double x_e = rayPos[0];
      double y_e = rayPos[1];
      double z_e = rayPos[2];

      MATRIX3 A;
      A << (x_a-x_b), (x_a-x_c), x_d,
           (y_a-y_b), (y_a-y_c), y_d,
           (z_a-z_b), (z_a-z_c), z_d;
      double det_A = A.determinant();

      MATRIX3 betamatrix;
      betamatrix << (x_a-x_e), (x_a-x_c), x_d, (y_a-y_e), (y_a-y_c), y_d, (z_a-z_e), (z_a-z_c), z_d;
      double det_beta = betamatrix.determinant();

     double beta = det_beta/det_A;

      MATRIX3 gammamatrix;
      gammamatrix << (x_a-x_b), (x_a-x_e), (x_d),(y_a-y_b), (y_a-y_e), (y_d), (z_a-z_b), (z_a-z_e), (z_d);
      
      

      double det_gamma = gammamatrix.determinant();

      double gamma = det_gamma/det_A;

      MATRIX3 tmatrix;
      tmatrix << (x_a-x_b), (x_a-x_c), (x_a-x_e), (y_a-y_b), (y_a-y_c), (y_a-y_e), (z_a-z_b), (z_a-z_c), (z_a-z_e);
      double det_t = tmatrix.determinant();

      double t_potential = det_t/det_A;

      if(gamma <=1 && gamma>=0 && beta >=0 && beta <= 1 -gamma && t_potential<t && t_potential>0){
        t = t_potential;
        return true;
        // sphereno = i;
      }
    return false;
}
  
  // if(t== INFINITY){ //didn't find any valid t
  //   // printf("YOU HSOULD BE HERE\n");
  //    return fa
  // }
  // else{
  //   // cout << "eye is " << e << endl;
  //   // cout << "d is " << d_persp << endl;
  //   // cout <<"return value of intersect is " << e+t*d_persp << "\n\n";
  //   return std::pair<VEC3,int> (e+t*d_persp, sphereno);
  //   //return t, primitive
  // }

  // if (t < 0) return false;

  
  
  // return true;


//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
void rayColor(const VEC3& rayPos, const VEC3& rayDir, VEC3& pixelColor, int recursetime) 
{
  // printf("in rayColor yay? \n");
  VEC3 Hadamardproduct;
  VEC3 eyefromsphere;
  light lightList[10]; 
  

  float y0 = rand() % 12+8; 
  float z0 = rand() % 32 + 28; 

  float y1 = rand() % 12+8; 
  float z1 = rand() % 32 + 28; 

  float y2 = rand() % 12+8; 
  float z2 = rand() % 32 + 28; 

  float y3 = rand() % 12+8; 
  float z3 = rand() % 32 + 28; 

  float y4 = rand() % 12+8; 
  float z4 = rand() % 32 + 28; 

  float y5 = rand() % 12+8; 
  float z5 = rand() % 32 + 28; 

  float y6 = rand() % 12+8; 
  float z6 = rand() % 32 + 28; 

  float y7 = rand() % 12+8; 
  float z7 = rand() % 32 + 28; 

  float y8 = rand() % 12+8; 
  float z8 = rand() % 32 + 28; 

  float y9 = rand() % 12+8; 
  float z9 = rand() % 32 + 28; 


  // create 10 different lights that are between z: y= 0 to 10 5 and -5

  
  // truncate(rotation.transpose()*extend(rayPos-center))
  VEC3 defaultvector = VEC3(-10, 10, 30);

  // VEC3 defaultvector = VEC3(-10, 10, -30);

  float theta = (45/180)*PI;

  MATRIX4 rotationmatrix; 

  rotationmatrix << cos(theta), 0, sin(theta), 0, 0, 1, 0, 0, -sin(theta), 0, cos(theta), 0, 0, 0, 0, 1;

  
  // lightposition.push_back(VEC3(-10, 5, 0));

  VEC3 lightvectorarr[100];


  // lightposition.push_back(VEC3(-10, 10, 30));
  // lightcolor.push_back(VEC3(1,1,1));
  // lightposition.push_back(VEC3(0,0.01,0));
  // lightcolor.push_back(VEC3(1,1,1));
  
  

 //1x1


VEC3 goallightvector = VEC3(-10, 10, 30);


 for(int i = 0; i<5; i++){

    float randnumx = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/5.0;
    float randnumy = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/5.0;
    float randnumz = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/5.0;

    float randx = goallightvector[0] + randnumx;
    float randy = goallightvector[1] + randnumy;  
    float randz = goallightvector[2] + randnumz;
    lightvectorarr[i] = VEC3(randx, randy, randz);
    lightposition.push_back(lightvectorarr[i]);
    // lightposition.push_back(goallightvector);
    lightcolor.push_back(VEC3(1,1,1));
}

goallightvector = VEC3(0,0.01,0);

for(int i = 0; i<5; i++){

    float randnumx = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/5.0;
    float randnumy = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/5.0;
    float randnumz = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/5.0;

    float randx = goallightvector[0] + randnumx;
    float randy = 0.01;  
    float randz = goallightvector[2] + randnumz;
    lightvectorarr[i+25] = VEC3(randx, randy, randz);
    // lightposition.push_back(lightvectorarr[i+25]);
    lightposition.push_back(goallightvector);
    lightcolor.push_back(VEC3(1,1,1));
}


  // for(int i = 0; i<25; i++){
  //   float randy = rand() % 14+6; 
  //   float randz = rand() % 34 + 26; 
  //   // float randz = rand() % 4 -4 ;
  //   lightvectorarr[i] = truncate(rotationmatrix*extend(VEC3(-10, randy, randz)- defaultvector))+defaultvector;
  //   lightposition.push_back(lightvectorarr[i]);
  //   lightcolor.push_back(VEC3(1, 1, 1));
  // }

  // defaultvector = VEC3(-5, 10, 0);

  // rotationmatrix << cos(theta), 0, sin(theta), 0, 0, 1, 0, 0, -sin(theta), 0, cos(theta), 0, 0, 0, 0, 1;

  // for(int i = 0; i<25; i++){

  //   float randy = rand() % 14+6; 
  //   // float randz = rand() % 34 + 26; 
  //   float randz = rand() % 2+0;
  //   lightvectorarr[i+25] = truncate(rotationmatrix*extend(VEC3(-10, randy, -randz)- defaultvector))+defaultvector;
  //   // lightposition.push_back(lightvectorarr[i+25]);
  //   lightposition.push_back(VEC3(0, 0, 0));
  //   lightcolor.push_back(VEC3(1, 1, 1));
  // }

 
  // VEC3 lightvector0 = truncate(rotationmatrix*extend(VEC3(-10, y0, z0)- defaultvector))+defaultvector;
  // VEC3 lightvector1 = truncate(rotationmatrix*extend(VEC3(-10, y1, z1)- defaultvector))+defaultvector;
  // VEC3 lightvector2 = truncate(rotationmatrix*extend(VEC3(-10, y2, z2)- defaultvector))+defaultvector;
  // VEC3 lightvector3 = truncate(rotationmatrix*extend(VEC3(-10, y3, z3)- defaultvector))+defaultvector;
  // VEC3 lightvector4 = truncate(rotationmatrix*extend(VEC3(-10, y4, z4)- defaultvector))+defaultvector;
  // VEC3 lightvector5 = truncate(rotationmatrix*extend(VEC3(-10, y5, z5)- defaultvector))+defaultvector;
  // VEC3 lightvector6 = truncate(rotationmatrix*extend(VEC3(-10, y6, z6)- defaultvector))+defaultvector;
  // VEC3 lightvector7 = truncate(rotationmatrix*extend(VEC3(-10, y7, z7)- defaultvector))+defaultvector;
  // VEC3 lightvector8 = truncate(rotationmatrix*extend(VEC3(-10, y8, z8)- defaultvector))+defaultvector;
  // VEC3 lightvector9 = truncate(rotationmatrix*extend(VEC3(-10, y9, z9)- defaultvector))+defaultvector;

  


 
  // lightposition.push_back(lightvector0);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector1);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector2);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector3);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector4);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector5);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector6);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector7);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector8);
  // lightcolor.push_back(VEC3(1, 1, 1));

  // lightposition.push_back(lightvector9);
  // lightcolor.push_back(VEC3(1, 1, 1));





  // lightposition.push_back(VEC3(-10, 0, -10)); 
  // lightcolor.push_back(VEC3(1, 1, 1));
  // pixelColor = VEC3(0,0,0);

  pixelColor = VEC3(1,1,1);
  int whatdidithit = -1; // 0 = cylinder, 1 = triangle

  // look for intersections
  int hitID = -1;
  float tMinFound = FLT_MAX;
  for (int y = 0; y < shape.size(); y++)
  {
    float tMin = FLT_MAX;


    if(cylinder[y]){
      if (rayCylinderIntersect(cylinderCenters[y], radiusCylinder[y], cylinderRotation[y], top[y], bottom[y], rayPos, rayDir, tMin, poleflag[y]))
      { 
        // is the closest so far?
        if (tMin < tMinFound)
        {
          tMinFound = tMin;
          hitID = y;
          whatdidithit = 0;
        }
      }
    }
    if(triangle[y]){
      if (rayTriangleIntersect(rayPos, rayDir, triangleVertex1[y], triangleVertex2[y], triangleVertex3[y], tMin))
      { 
        // is the closest so far?
        if (tMin < tMinFound)
        {
          tMinFound = tMin;
          hitID = y;
          whatdidithit = 1;
        }
      }
    }
    if(sphere[y]){
      if (raySphereIntersect(sphereCenters[y], sphereRadii[y], rayPos, rayDir,tMin))
      { 
        // is the closest so far?
        if (tMin < tMinFound)
        {
          tMinFound = tMin;
          hitID = y;
          whatdidithit = 2;
        }
      }
    }
    
  }

  //returns white
  if (hitID == -1){
    return;
  }
  int flip = 0;
  
  VEC3 c_r;
  VEC3 c_l;
  pixelColor = VEC3(0,0,0);
  VEC3 normal;
  VEC3 collisionpt = rayPos + tMinFound*rayDir; 
  // set to the sphere color
  if(whatdidithit == 0){ //cylinder
    c_r = cylinderColors[hitID];

    VEC3 newcollisionpt =  truncate(cylinderRotation[hitID].transpose()*extend(collisionpt-cylinderCenters[hitID]));

     normal = VEC3(newcollisionpt[0], newcollisionpt[1], 0);

    // normal = newcollisionpt-VEC3(cylinderCenters[hitID][0], cylinderCenters[hitID][1], collisionpt[2]);
    
    normal = truncate(cylinderRotation[hitID]*extend(normal));

    normal = normal/normal.norm();
  }
  if(whatdidithit == 1){ //triangle
    c_r = triangleColors[hitID];
      if(hitID %2 == 0){
         normal = (triangleVertex1[hitID]-collisionpt).cross(triangleVertex2[hitID]-collisionpt);
        normal = normal/normal.norm();
      }
      else{
         normal = -(triangleVertex1[hitID]-collisionpt).cross(triangleVertex2[hitID]-collisionpt);
        normal = normal/normal.norm();
      }
    
  }
  if(whatdidithit == 2){ //sphere
    c_r = sphereColors[hitID];
    normal=(collisionpt-(sphereCenters[hitID]));
    normal = normal/normal.norm();
  }


  

  bool skipflag = false;
  VEC3 lightvector;
  VEC3 reflection;
  VEC3 reflectionformirror;
  int recursioncompleteforlight1 = 0;


  //  theta = acos((reflectionformirror.dot(normal))/(reflectionformirror.norm()*normal.norm()));

  // // MATRIX4 rotationmatrix; 

  // rotationmatrix << cos(theta), 0, sin(theta), 0, 0, 1, 0, 0, -sin(theta), 0, cos(theta), 0, 0, 0, 0, 1;

  // reflectionformirror = rayDir + 2*(normal.dot(-rayDir))*normal;
  // reflectionformirror = reflectionformirror/reflectionformirror.norm();

  // VEC3 reflectionformirrorarr[25];

  // int maxlimity = reflectionformirror[1]+2.0;
  // int minlimity = reflectionformirror[1]-2.0;

  // int maxlimitx = reflectionformirror[0]+2.0;
  // int minlimitx = reflectionformirror[0]-2.0;

  // for(int i = 0; i<25; i++){

  //   ((float) rand()) / (float) RAND_MAX
  //   float randy = rand() % maxlimity + minlimity; 
  //   float randx = rand() % maxlimitx + minlimitx; 
  //   // float randz = rand() % 4 -4 ;
  //   reflectionformirrorarr[i] = VEC3(randx, randy, reflectionformirror[2])- reflectionformirror))+reflectionformirror;
  //   glossyreflection.push_back(reflectionformirrorarr[i]);
  // }


  for(int i = 0; i<10; i++){
    lightvector = lightposition[i]-collisionpt;
    lightvector = lightvector/lightvector.norm();
    reflection = -lightvector + 2*(normal.dot(lightvector))*normal;
    reflection = reflection/reflection.norm();
    // reflectionformirror = rayDir + 2*(normal.dot(-rayDir))*normal;
    // reflectionformirror = reflectionformirror/reflectionformirror.norm();

    VEC3 newcollisionptforshadows = collisionpt+E*lightvector;



    if(mirror[hitID] == true){


      // VEC3 defaultvector = VEC3(-10, 10, -30);

      // float theta = acos((reflectionformirror.dot(normal))/(reflectionformirror.norm()*normal.norm()));

      // MATRIX4 rotationmatrix; 

      // rotationmatrix << cos(theta), 0, sin(theta), 0, 0, 1, 0, 0, -sin(theta), 0, cos(theta), 0, 0, 0, 0, 1;

      
      // lightposition.push_back(VEC3(-10, 5, 0));

      // VEC3 reflectionformirrorarr[25];

      // int maxlimity = reflectionformirror[1]+2.0;
      // int minlimity = reflectionformirror[1]-2.0;

      // int maxlimitx = reflectionformirror[0]+2.0;
      // int minlimitx = reflectionformirror[0]-2.0;

      // for(int i = 0; i<25; i++){
      //   float randy = rand() % maxlimity + minlimity; 
      //   float randx = rand() % maxlimitx + minlimitx; 
      //   // float randz = rand() % 4 -4 ;
      //   reflectionformirrorarr[i] = truncate(rotationmatrix*extend(VEC3(randx, randy, reflectionformirror[2])- reflectionformirror))+reflectionformirror;
      //   glossyreflection.push_back(reflectionformirrorarr[i]);
      // }


      
  //  theta = acos((reflectionformirror.dot(normal))/(reflectionformirror.norm()*normal.norm()));

  // // MATRIX4 rotationmatrix; 

  // rotationmatrix << cos(theta), 0, sin(theta), 0, 0, 1, 0, 0, -sin(theta), 0, cos(theta), 0, 0, 0, 0, 1;

  reflectionformirror = rayDir + 2*(normal.dot(-rayDir))*normal;
  reflectionformirror = reflectionformirror/reflectionformirror.norm();

  VEC3 reflectionformirrorarr[100];

  // int maxlimity = reflectionformirror[1]+2.0;
  // int minlimity = reflectionformirror[1]-2.0;

  // int maxlimitx = reflectionformirror[0]+2.0;
  // int minlimitx = reflectionformirror[0]-2.0;

  for(int i = 0; i<25; i++){ //50 before

    float randnumx = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/25.0;
    float randnumy = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/25.0;
    float randnumz = (((((float) rand()) / (float) RAND_MAX)*2)-1.0)/25.0;

    float randx = reflectionformirror[0] + randnumx;
    float randy = reflectionformirror[1] + randnumy;  
    float randz = reflectionformirror[2] + randnumz;
    reflectionformirrorarr[i] = VEC3(randx, randy, randz);
    // glossyreflection.push_back(reflectionformirrorarr[i]);
}




          
      if(recursioncompleteforlight1){
        recursioncompleteforlight1 = 0;
      }
      else{
        recursetime++;
      }

      if(recursetime<11){
        
        for(int i = 0; i< 25; i++){
        //   // printf("i is %d\n", i);
          VEC3 originalcolor = pixelColor;
          VEC3 newcollisionptforreflection = collisionpt+E*reflectionformirrorarr[i];
          rayColor(newcollisionptforreflection, reflectionformirrorarr[i], pixelColor, recursetime);
          recursioncompleteforlight1 = 1;
          // pixelColor = originalcolor+pixelColor;
          pixelColor = originalcolor+(1.0/25.0)*pixelColor;
        
        }
        // pixelColor = (1.0/25.0)*pixelColor;

        // need to average it out


      }
      // else if(recursetime > 1){
      //     printf("you shouldn't be here\n");
      // }
      
      //  cout << pixelColor << endl;
      //   printf("\n");
          

          
    }
    else{

    





    float tMinFound = FLT_MAX;
     for (int y = 0; y < shape.size(); y++)
      {
        float tMin = FLT_MAX;
        if(cylinder[y]){
          if (rayCylinderIntersect(cylinderCenters[y], radiusCylinder[y], cylinderRotation[y], top[y], bottom[y], newcollisionptforshadows, lightvector, tMin, poleflag[y]))
          { 
            skipflag = true;
          }
        }
        if(triangle[y]){
          if (rayTriangleIntersect(newcollisionptforshadows, lightvector, triangleVertex1[y], triangleVertex2[y], triangleVertex3[y], tMin))
          { 
            skipflag = true;
          }
        }
        if(sphere[y]){
          if (raySphereIntersect(sphereCenters[y], sphereRadii[y], newcollisionptforshadows, lightvector,tMin))
          { 
            skipflag = true;
          }
        }
    
      }
  

    if(skipflag){
      // printf("NEED TO SKIP\n");
      continue;
    }

    // c_l = lightcolor[0];
    // eyefromsphere = rayPos-collisionpt;
    // eyefromsphere = eyefromsphere/eyefromsphere.norm();
    // double dotproduct_diffuse = normal.dot(lightvector);
    // double dotproduct_highlight = reflection.dot(eyefromsphere);
    // VEC3 diffuseandhighlightvector = max(0.0,dotproduct_diffuse)*c_l +pow((max(0.0,dotproduct_highlight)), 10.0)*c_l;
    // Hadamardproduct = VEC3(c_r[0]*diffuseandhighlightvector[0], c_r[1]*diffuseandhighlightvector[1], c_r[2]*diffuseandhighlightvector[2]);
    // VEC3 originalcolor = pixelColor;
    // pixelColor = pixelColor + Hadamardproduct; 


    c_l = lightcolor[0];
    eyefromsphere = rayPos-collisionpt;
    eyefromsphere = eyefromsphere/eyefromsphere.norm();
    double dotproduct_diffuse = normal.dot(lightvector);
    double dotproduct_highlight = reflection.dot(eyefromsphere);
    VEC3 diffuseandhighlightvector = max(0.0,dotproduct_diffuse)*c_l+pow((max(0.0,dotproduct_highlight)), 10.0)*c_l;
    Hadamardproduct = VEC3(c_r[0]*diffuseandhighlightvector[0], c_r[1]*diffuseandhighlightvector[1], c_r[2]*diffuseandhighlightvector[2]);
    VEC3 originalcolor = pixelColor;
    pixelColor = pixelColor + Hadamardproduct;
    // pixelColor = c_r;
    }
  }
  pixelColor = pixelColor/5.0;
  lightposition.clear();
  lightcolor.clear();

  return;

  //offset point by 1/4 of x or y based on quadrant

}
  
  // No intersection, return white
  

  // // set to the sphere colorß
  // if(whatdidithit == 0){ //cylinder
  //   pixelColor = cylinderColors[hitID];
  // }
  // if(whatdidithit == 1){ //triangle
  //   pixelColor = triangleColors[hitID];
  // }
  // if(whatdidithit == 2){
  //   pixelColor = sphereColors[hitID];
  // }
  


// for (int y = 0; y<triangleVertex1.size(); y++){
//     float tMin = FLT_MAX;
  
//   if (rayTriangleIntersect(rayPos, rayDir, triangleVertex1[y], triangleVertex2[y], triangleVertex3[y], tMin))
//     { 
//       // is the closest so far?
//       if (tMin < tMinFound)
//       {
//         tMinFound = tMin;
//         hitID = y;
//       }
//     }

// }


// std::pair<VEC3,int>  intersectScene(VEC3 e, VEC3 d_persp, int refraction){
//   // VEC3 collisionpoint = VEC3(INFINITY, INFINITY, INFINITY); 
//   double t = INFINITY;
//   int sphereno = -1;

//   // pass in rotation (save under cylinder)

//   // EXTEND HERE
//   // o_cylinder = (rotation.transpose)*(e-cylinder.center());
//   // d_cylinder = (rotation.transpose)*d_persp;


//   // double A = (d[0]*d[0])+(d[1]*d[1]);
//   // double B = (2*d[0]*o[0])+(2*d[1]*o[1]);
//   // double C = (o[0]*o[0])+(o[1]*o[1])-0


//   // truncate before returning

//   // truncate center in other function






//   // in other function:
//   // adjustedcenterfornormal = center;
//   // adjustedcenterfornormal[2] = center[2]+(pt[2]-center[2]);
//   // normal = (pt-(center+())


//   for(int i = 0; i<sphereCenters.size(); i++){
//     if(triangle[i] == true){
      
//       VEC3 a = vertex1[i];
//       VEC3 b = vertex2[i];
//       VEC3 c = vertex3[i];
//       double x_a = a[0];
//       double y_a = a[1];
//       double z_a = a[2];

//       double x_b = b[0];
//       double y_b = b[1];
//       double z_b = b[2];

//       double x_c = c[0];
//       double y_c = c[1];
//       double z_c = c[2]; 

//       double x_d = d_persp[0];
//       double y_d = d_persp[1];
//       double z_d = d_persp[2];

//       double x_e = e[0];
//       double y_e = e[1];
//       double z_e = e[2];

//       MATRIX3 A;
//       A << (x_a-x_b), (x_a-x_c), x_d,
//            (y_a-y_b), (y_a-y_c), y_d,
//            (z_a-z_b), (z_a-z_c), z_d;
//       double det_A = A.determinant();

//       MATRIX3 betamatrix;
//       betamatrix << (x_a-x_e), (x_a-x_c), x_d, (y_a-y_e), (y_a-y_c), y_d, (z_a-z_e), (z_a-z_c), z_d;
//       double det_beta = betamatrix.determinant();

//      double beta = det_beta/det_A;

//       MATRIX3 gammamatrix;
//       gammamatrix << (x_a-x_b), (x_a-x_e), (x_d),(y_a-y_b), (y_a-y_e), (y_d), (z_a-z_b), (z_a-z_e), (z_d);
      
      

//       double det_gamma = gammamatrix.determinant();

//       double gamma = det_gamma/det_A;

//       MATRIX3 tmatrix;
//       tmatrix << (x_a-x_b), (x_a-x_c), (x_a-x_e), (y_a-y_b), (y_a-y_c), (y_a-y_e), (z_a-z_b), (z_a-z_c), (z_a-z_e);
//       double det_t = tmatrix.determinant();

//       double t_potential = det_t/det_A;

//       // det_tmatrix = tmatrix.determinant();

//       // if(gamma<0 || gamma > 1){
//       //   return std::pair<VEC3,int> (VEC3(INFINITY, INFINITY, INFINITY), sphereno) ;
//       // }

//       // if(beta < 0 || beta > 1-gamma){
//       //   return std::pair<VEC3,int> (VEC3(INFINITY, INFINITY, INFINITY), sphereno);
//       // }

//       if(gamma <=1 && gamma>=0 && beta >=0 && beta <= 1 -gamma && t_potential<t && t_potential>0){
//         t = t_potential;
//         sphereno = i;
//       }

//       // return std::pair<VEC3,int> (e+t*d_persp, sphereno);
      


//     }
//     else{

//     // printf("here\n");
//     VEC3 c = sphereCenters[i];

    
//     int R = sphereRadii[i];
//     double A = d_persp.dot(d_persp);
//     double B = 2*d_persp.dot(e-c);
//     double C = (e-c).dot(e-c)-(R*R); 
//     double checkingelement = B*B-(4*A*C); 

//     const VEC3 op = sphereCenters[i] - e;

//     const float b = op.dot(d_persp);
//     float det = b * b - op.dot(op) + 0.05 * 0.05;




//     if(det>=0){ //has not imaginary root
//       double t_1 = (-B+sqrt(checkingelement))/(2*A);
//       double t_2 = (-B-sqrt(checkingelement))/(2*A);
      
//       // double t_1 = b- det;
//       // double t_2 = b+ det;


//       if(t_1 > 0 && t_2 > 0){
//         t = min(t, min(t_1, t_2)); 
//         if(t == min(t_1, t_2)){
//           // printf("in 1st conditional in intersect\n");
//           sphereno = i;
//         }
        

//         // if(t_1 == t_2 && t_1 < t){
//         //   //one positive, real-valued root
//         //   t = t_1;
//         //   sphereno = i; 
//         //   // return (e + t_1*d_persp);
//         // }
//         // else if(t_1<t_2 && t_1<t){
//         //   //t1 smaller -> keep t1
//         //   t= t_1;
//         //   sphereno = i;
//         //   // return (e + t_1*d_persp);
//         // }
//         // else if(t_2<t_1 && t_2<t){
//         //   //t2 smaller -> keep t2
//         //   t = t_2;
//         //   sphereno = i;
          
//         //   // return (e + t_2*d_persp);
//         // }
//       }
//       // if(i>3 && sphereno > 2){
//       //   printf("ERRORRRRR\n");
//       //   exit(0);
//       // }
//       else if(refraction && t_1>0 && t_2<0 && t_1<t){
//         // printf("t_1>0\n");
//         t= t_1;
//         sphereno = i;
//         // return (e + t_1*d_persp);
//       }
//       else if(refraction && t_2>0 && t_1<0 && t_2<t){
//         // printf("t_2>0\n");
//         t= t_2;
//         sphereno = i;
//         // return (e + t_2*d_persp);
//       }
//       // else{
//       //   return VEC3(INFINITY, INFINITY, INFINITY);
//       // }
//     } 
//   }
    
    
  
//   }
//   // printf("d_persp[0] is %f, d_persp[1] is %f, d_persp[2] is %f\n", d_persp[0], d_persp[1], d_persp[2]);
//   // printf("here\n");
//   // if(d_persp[0] == -0.947531 && d_persp[1] == 0.237824 && d_persp[2] == 0.213601){
//   //     printf("YOU SHOULD BE HERE\n");
//       // printf("t is %f\n", t);
//       // cout << "collision pt right after finding t is : " << e+t*d_persp << "\n\n";
//     // }
//   if(t== INFINITY){ //didn't find any valid t
//     // printf("YOU HSOULD BE HERE\n");
//      return std::pair<VEC3,int> (VEC3(INFINITY, INFINITY, INFINITY), sphereno);
//   }
//   else{
//     // cout << "eye is " << e << endl;
//     // cout << "d is " << d_persp << endl;
//     // cout <<"return value of intersect is " << e+t*d_persp << "\n\n";
//     return std::pair<VEC3,int> (e+t*d_persp, sphereno);
//     //return t, primitive
//   }
  
//    // return collision 
//   // std::pair<T1, T2> function 
//   // return std::pair<T1, T2>( , );

//   // if(checkingelement<0){
//   //   return VEC3(INFINITY, INFINITY, INFINITY);;
//   // }
//   // double t_1 = (-B+sqrt(B*B-4*A*C))/(2*A);
//   // double t_2 = (-B-sqrt(B*B-4*A*C))/(2*A);

//   // if(t_1 > 0 && t_2 > 0){
//   //   if(t_1 == t_2){
//   //     //one positive, real-valued root
//   //     return (e + t_1*d_persp);
//   //   }
//   //   else if(t_1<t_2){
//   //     //t1 smaller -> keep t1
//   //     return (e + t_1*d_persp);
//   //   }
//   //   else{
//   //     //t2 smaller -> keep t2
//   //     return (e + t_2*d_persp);
//   //   }
//   // }
//   // else if(t_1>0){
//   //   return (e + t_1*d_persp);
//   // }
//   // else if(t_2>0){
//   //   return (e + t_2*d_persp);
//   // }
//   // else{
//   //   return VEC3(INFINITY, INFINITY, INFINITY);
//   // }

 

// }


// VEC3 generateRay(double alpha_air, double alpha_glass, VEC3 n, VEC3 in, int tryingtoexit){
//   //cos(theta) = (dot product of 2 vectors)/(product of magnitudes of vectors)
//   // double theta = acos(n.dot(in)/(n.norm()*in.norm()));
//   // double theta = asin((n.cross(-in)).norm()/(n.norm()*(-in).norm()));
//   // in = in/in.norm();
//   double theta = atan(n.dot(in)/(n.norm()*in.norm()));
//   double alpha_ratio = alpha_air/alpha_glass;
//   // double sqrtpart= 1-(alpha_ratio*alpha_ratio)*(1-(in.dot(n)*in.dot(n)));
//   double sqrtpart = 1-(alpha_ratio*alpha_ratio)*(1-(in.dot(n)*in.dot(n)));
//   if(sqrtpart<0){ //need to check if exiting?
//     return VEC3(INFINITY, INFINITY, INFINITY);
//   }
  
//   // VEC3 out = ((alpha_ratio*sin(theta))*((in+n*cos(theta))/(sin(theta)))) - sqrt(sqrtpart)*n;
//   // VEC3 out = alpha_ratio*(in+n*cos(theta))
//   VEC3 out = alpha_ratio*(in-n*(in.dot(n))) - n*sqrt(sqrtpart);
//   out.normalize();

//   // if(isnan(out[0]) || isnan(out[1]) || isnan(out[2])){
//   //   return VEC3(INFINITY, INFINITY, INFINITY);
//   // }
//   return out;

// }

// VEC3 rayColor(VEC3 e, VEC3 d_persp, int recursetime, int in){
//   // static int recursetime = 0;
//   // if(recursetime == 1){
//   //   cout << "before calling intersect, at top of rayColor d_persp is " << d_persp << endl;
//   // }
//   // cout << e << endl;
//   // cout << d_persp << endl;
  
  
//   std::pair<VEC3,int> returnofintersection= intersectScene(e, d_persp, 0);
//   VEC3 collisionpt = returnofintersection.first;
//   int sphereno = returnofintersection.second;
//   VEC3 normal;
//   VEC3 Hadamardproduct;
//   VEC3 lightvector;
//   VEC3 reflection; 
//   VEC3 eyefromsphere;
//   VEC3 shadowray; 
//   VEC3 reflectionformirror;
//   light lightList[2]; 
//   lightList[0].position = VEC3(10, 10, 5); 
//   lightList[0].color = VEC3(1, 1, 1);
//   lightList[1].position = VEC3(-10, 10, 7.5); 
//   lightList[1].color = VEC3(0.5, 0.25,0.25);
//   VEC3 color0 = VEC3(0,0,0);
//   VEC3 color1 = VEC3(0,0,0);

  
  
//   VEC3 c_l;
//     if(collisionpt == VEC3(INFINITY, INFINITY, INFINITY)){ //could also check sphereno == -1?
//       // printf("YOU SHOULD BE HERE BECAUSE IT RETURNED INFINITY\n");
      
//       return VEC3(0,0,0);
//     }
//     else{
      
//       int recursioncompleteforlight1 = 0;
//       if(triangle[sphereno] == true){
//         // sphereno == 1 || sphereno == 203){
//         normal =- (vertex1[sphereno]-collisionpt).cross(vertex2[sphereno]-collisionpt);
//         // normal =- (sphereList[sphereno].vertex1-collisionpt).cross(sphereList[sphereno].vertex2-collisionpt);
//         normal = normal/normal.norm();
//       }
//       else{
//         // normal=(collisionpt-(sphereList[sphereno].center));
//         normal=(collisionpt-(sphereCenters[sphereno]));
//         normal = normal/normal.norm();
//       }
      
//       VEC3 c_r = sphereColors[sphereno];
//       VEC3 color = VEC3(0,0,0);
//       for(int i=0; i<2; i++){
//         // printf("on light: %d\n", i);
//         lightvector = (lightList[i].position)-collisionpt;  
//         lightvector = lightvector/lightvector.norm();
//         reflection = -lightvector + 2*(normal.dot(lightvector))*normal;
//         reflection = reflection/reflection.norm();
//         reflectionformirror = d_persp + 2*(normal.dot(-d_persp))*normal;
//         reflectionformirror = reflectionformirror/reflectionformirror.norm();






//         if(mirror[sphereno] == true){

//           if(recursioncompleteforlight1){
//             recursioncompleteforlight1 = 0;
//           }
//           else{
//             recursetime++;
//           }
          
         
//           if(recursetime<11){
            
//             VEC3 newcollisionptforreflection = collisionpt+E*reflectionformirror;
           
//             color = rayColor(newcollisionptforreflection, reflectionformirror, recursetime, 0);

//             recursioncompleteforlight1 = 1;
//           }
         

          
//         }
//         else if (refraction[sphereno] == true){ //REFRACTION


//           VEC3 refractedRay;
//           double alpha_air = 1;
//           double alpha_glass = 1.5;
//           double alpha_1 = alpha_air;
//           double alpha_2 = alpha_glass;

//           double theta = acos(d_persp.dot(normal));

//           d_persp.normalize();
//           //-e?
//           // if(in == 0){ //entering glass
//             refractedRay = generateRay(alpha_air, alpha_glass, normal, d_persp, 0);
//             in=1;
//             if(refractedRay == VEC3(INFINITY, INFINITY, INFINITY)){ //inside sphere after going out
//               continue; //color = black?
//             }

//           VEC3 altcollisionpt = collisionpt + E*refractedRay;
//           refractedRay = refractedRay/refractedRay.norm();
//           double phi = acos(refractedRay.dot(-normal));

//           returnofintersection= intersectScene(altcollisionpt, refractedRay, 1);
//           collisionpt = returnofintersection.first;
//           sphereno = returnofintersection.second;
//           normal=(collisionpt-(sphereCenters[sphereno]));
//           normal = normal/normal.norm();


            
//           refractedRay = generateRay(alpha_glass, alpha_air, -normal, refractedRay, 1);
//           theta = acos(refractedRay.dot(normal));

//           in = 0; 
        
//           if(refractedRay == VEC3(INFINITY, INFINITY, INFINITY)){ //inside sphere after going out
//             continue; 
//           }
//           refractedRay = refractedRay/refractedRay.norm();

//           double p_parallel = ((alpha_2*cos(theta))-(alpha_1*cos(phi)))/((alpha_2*cos(theta))+(alpha_1*cos(phi)));

//           double p_perpindicular = ((alpha_1*cos(theta))-(alpha_2*cos(phi)))/((alpha_1*cos(theta))+(alpha_2*cos(phi)));

//           double k_reflect = 0.5*(p_parallel*p_parallel+p_perpindicular*p_perpindicular);

//           double k_refract = 1-k_reflect;

//           VEC3 newcollisionptforrefraction = collisionpt + E*refractedRay;

//           VEC3 newcollisionptforreflection = collisionpt+E*reflectionformirror;
           
//           if(i == 0){
//             color0 = k_refract*rayColor(newcollisionptforrefraction, refractedRay, 0, in);
//             color1 = k_reflect* rayColor(newcollisionptforreflection, reflectionformirror, recursetime, 0);
//             color = color0+color1;
//           }
//           else{
//             if(color0 == VEC3(0,0,0)&& color1 != VEC3(0,0,0)){
//               color1 = color + k_refract*rayColor(newcollisionptforrefraction, refractedRay, 0, in) + k_reflect* rayColor(newcollisionptforreflection, reflectionformirror, recursetime, 0);
//             }
    
//           }
//           // color = color + k_refract*rayColor(newcollisionptforrefraction, refractedRay, sphereList, 0, in) + k_reflect* rayColor(newcollisionptforreflection, reflectionformirror, sphereList, recursetime, 0);
//         }
//         else{ //shadowing
//           VEC3 newcollisionptforshadows = collisionpt+E*lightvector;
//           std::pair<VEC3,int> returnofshadowrayintersection=(intersectScene(newcollisionptforshadows, lightvector,0));
        
        
//           int defdocolor = 0;
          
         

//           if(returnofshadowrayintersection.first != VEC3(INFINITY, INFINITY, INFINITY) && defdocolor == 0){ //there is a shadow
            
//             continue;
//           }
          

//             c_l = lightList[i].color;
//             eyefromsphere = e-collisionpt;
//             eyefromsphere = eyefromsphere/eyefromsphere.norm();
//             double dotproduct_diffuse = normal.dot(lightvector);
//             double dotproduct_highlight = reflection.dot(eyefromsphere);
//             VEC3 diffuseandhighlightvector = max(0.0,dotproduct_diffuse)*c_l+pow((max(0.0,dotproduct_highlight)), 10.0)*c_l;
//             Hadamardproduct = VEC3(c_r[0]*diffuseandhighlightvector[0], c_r[1]*diffuseandhighlightvector[1], c_r[2]*diffuseandhighlightvector[2]);
//             VEC3 originalcolor = color;
//             color = color + Hadamardproduct;
            
        
//         }
        
        
//       }
//       return color;
      
//     }


  

  
// }

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
float clamp(float value)
{
  if (value < 0.0)      return 0.0;
  else if (value > 1.0) return 1.0;
  return value;
}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
void renderImage(int& xRes, int& yRes, const string& filename) 
{

  
  // allocate the final image
  const int totalCells = xRes * yRes;
  float* ppmOut = new float[3 * totalCells];

  // compute image plane
  const float halfY = (lookingAt - eye).norm() * tan(45.0f / 360.0f * M_PI);
  const float halfX = halfY * 4.0f / 3.0f;

  const VEC3 cameraZ = (lookingAt - eye).normalized();
  const VEC3 cameraX = up.cross(cameraZ).normalized();
  const VEC3 cameraY = cameraZ.cross(cameraX).normalized();

  





  // float* values = new float[xRes*yRes*3];
  
  // VEC3 e = eye;


  // // VEC3 g = VEC3(lookat_x-e_x, lookat_y-e_y,  lookat_z-e_z);
  // VEC3 g = lookingAt - e;




  // VEC3 w;
  // if(g.norm() == 0){
  //   w = VEC3(0, 0, 0);
  // }
  // else{
  //   w = -g/(g.norm());
  // }

  // VEC3 u;
  // if((up.cross(w)).norm() == 0){
  //   u = VEC3(0, 0, 0);
  // }
  // else{
  //   u = (up.cross(w))/((up.cross(w)).norm());
  // }

  // VEC3 v = w.cross(u);

  // double fozy = 65.0;
  // fozy = (65.0/180.0)*PI; 
  // double aspect = (double)xRes/(double)yRes; // = w/h -> h*aspect = w -> w = 2*t*aspect = 2*r; (w=r-l) -> r = t*aspect

  // double n = 1.0;

    
  // double t = tan(0.5*fozy)*n;
  // double b = -tan(0.5*fozy)*n;

  // double r = t*aspect;
  // double l = -t*aspect;

  // double n_x = 2.0;
  // double n_y = 2.0;

  // VEC3 s;
  // VEC3 d_persp;


  // for(int y = yRes-1; y >= 0; y--){
  //   for(int x= 0; x<xRes; x++){

  //     double x_double = (double)x;
  //     double y_double = (double)y;
  //     double xRes_double = (double)xRes;
  //     double yRes_double = (double)yRes;
      

  //     // double new_x = ((((double)x)/((double)xRes))-0.5)*2;
  //     // double new_y = ((((double)y)/((double)yRes))-0.5)*2;

  //     double new_x = ((x_double/xRes_double)-0.5)*2;
  //     double new_y = ((y_double/yRes_double)-0.5)*2;
      
      
  //     double u_comp = (l+((r-l)*(new_x+0.5)))/n_x;
  //     double v_comp = (b+(t-b)*(new_y+0.5))/n_y;
  //     s = u_comp*u + v_comp*v - n*w;
  //     d_persp = (s-e);
  //     // d_persp = d_persp/d_persp.norm();
  //     cout << d_persp << endl; 
  //     exit(0);
  //     int index = (xRes-x-1) + (yRes -y -1) * xRes;
  //     // for(int i = 0; i<3; i++){
  //     // pixel = VEC3(x, y, 0.0);
      
  //     values[3*index] =  (rayColor(e, d_persp, 0, 0))[0]*255;
  //     values[3 * index + 1] = (rayColor(e, d_persp, 0, 0))[1]*255;
  //     values[3 * index + 2] = (rayColor(e, d_persp, 0, 0))[2]*255;
  //     // }
      
  //   }
  // }












  for (int y = 0; y < yRes; y++) 
    for (int x = 0; x < xRes; x++) 
    {
    
      // const float ratioX = 1.0f - x / float(xRes) * 2.0f;
      // const float ratioY = 1.0f - y / float(yRes) * 2.0f;

      const float ratioX1 = 1.0f - ((float)x+0.5) / float(xRes) * 2.0f;
      const float ratioY1 = 1.0f - ((float)y +0.5)  / float(yRes) * 2.0f;

      const float ratioX2 = 1.0f - ((float)x-0.5) / float(xRes) * 2.0f;
      const float ratioY2 = 1.0f - ((float)y +0.5)  / float(yRes) * 2.0f;

      const float ratioX3 = 1.0f - ((float)x-0.5) / float(xRes) * 2.0f;
      const float ratioY3 = 1.0f - ((float)y-0.5)  / float(yRes) * 2.0f;

      const float ratioX4 = 1.0f - ((float)x+0.5) / float(xRes) * 2.0f;
      const float ratioY4 = 1.0f - ((float)y-0.5)  / float(yRes) * 2.0f;

      const float ratioX5 = 1.0f - x / float(xRes) * 2.0f;
      const float ratioY5 = 1.0f - y  / float(yRes) * 2.0f;

      const VEC3 rayHitImage1 = lookingAt + 
                               ratioX1 * halfX * cameraX +
                               ratioY1 * halfY * cameraY;

      const VEC3 rayHitImage2 = lookingAt + 
                               ratioX2 * halfX * cameraX +
                               ratioY2 * halfY * cameraY;

      const VEC3 rayHitImage3 = lookingAt + 
                               ratioX3 * halfX * cameraX +
                               ratioY3 * halfY * cameraY;

      const VEC3 rayHitImage4 = lookingAt + 
                               ratioX4 * halfX * cameraX +
                               ratioY4 * halfY * cameraY;  

    const VEC3 rayHitImage5 = lookingAt + 
                               ratioX5 * halfX * cameraX +
                               ratioY5 * halfY * cameraY;                       

      //create 2 or 4 rayHitImage bc have 2/4
      const VEC3 rayDir1 = (rayHitImage1 - eye).normalized();
      const VEC3 rayDir2 = (rayHitImage2 - eye).normalized();
      const VEC3 rayDir3 = (rayHitImage3 - eye).normalized();
      const VEC3 rayDir4 = (rayHitImage4 - eye).normalized();
      const VEC3 rayDir5 = (rayHitImage5 - eye).normalized();
      // const VEC3 rayHitImage = lookingAt + 
      //                          ratioX * halfX * cameraX +
      //                          ratioY * halfY * cameraY;
      //create 2 or 4 rayHitImage bc have 2/4
      // const VEC3 rayDir = (rayHitImage - eye).normalized();
      // cout << rayDir << endl;
      // exit(0);
      // ppmOut[3*(y * xRes + x)] =  clamp((rayColor(eye, rayDir, 0, 0))[0])*255.0f;
      // ppmOut[3 * (y * xRes + x) + 1] = clamp((rayColor(eye, rayDir, 0, 0))[1])*255.0f;
      // ppmOut[3 * (y * xRes + x) + 2] = clamp((rayColor(eye, rayDir, 0, 0))[2])*255.0f;




      // get the color
      VEC3 color;
      rayColor(eye, rayDir1, color, 0);
      VEC3 originalcolor = color; 
      rayColor(eye, rayDir2, color, 0);
      originalcolor = originalcolor+color;
      rayColor(eye, rayDir3, color, 0);
      originalcolor = originalcolor+color;
      rayColor(eye, rayDir4, color, 0);
      originalcolor = originalcolor+color;
      rayColor(eye, rayDir5, color, 0);
      originalcolor = originalcolor+color;
      color = originalcolor/5.0;


      // // set, in final image
      ppmOut[3 * (y * xRes + x)] = clamp(color[0]) * 255.0f;
      ppmOut[3 * (y * xRes + x) + 1] = clamp(color[1]) * 255.0f;
      ppmOut[3 * (y * xRes + x) + 2] = clamp(color[2]) * 255.0f;
    }
  writePPM(filename, xRes, yRes, ppmOut);

  delete[] ppmOut;
}

//////////////////////////////////////////////////////////////////////////////////
// Load up a new motion captured frame
//////////////////////////////////////////////////////////////////////////////////
void setSkeletonsToSpecifiedFrame(int frameIndex)
{
  if (frameIndex < 0)
  {
    printf("Error in SetSkeletonsToSpecifiedFrame: frameIndex %d is illegal.\n", frameIndex);
    exit(0);
  }
  if (displayer.GetSkeletonMotion(0) != NULL)
  {
    int postureID;
    if (frameIndex >= displayer.GetSkeletonMotion(0)->GetNumFrames())
    {
      cout << " We hit the last frame! You might want to pick a different sequence. " << endl;
      postureID = displayer.GetSkeletonMotion(0)->GetNumFrames() - 1;
    }
    else 
      postureID = frameIndex;
    displayer.GetSkeleton(0)->setPosture(* (displayer.GetSkeletonMotion(0)->GetPosture(postureID)));
  }
}

//////////////////////////////////////////////////////////////////////////////////
// Build a list of spheres in the scene
//////////////////////////////////////////////////////////////////////////////////
void buildScene()
{
  cylinderCenters.clear();
  radiusCylinder.clear();
  cylinderColors.clear();
  cylinderRotation.clear();
  cylinderColors.clear();
  top.clear();
  bottom.clear();
  shape.clear();
  cylinder.clear();
  triangle.clear();
  triangleVertex1.clear();
  triangleVertex2.clear();
  triangleVertex3.clear();
  triangleColors.clear();
  lightposition.clear();
  lightcolor.clear();

  displayer.ComputeBonePositions(DisplaySkeleton::BONES_AND_LOCAL_FRAMES);

  // retrieve all the bones of the skeleton
  vector<MATRIX4>& rotations = displayer.rotations();
  vector<MATRIX4>& scalings  = displayer.scalings();
  vector<VEC4>& translations = displayer.translations();
  vector<float>& lengths     = displayer.lengths();

  // build a sphere list, but skip the first bone, 
  // it's just the origin
  int totalBones = rotations.size();
  for (int x = 1; x < totalBones; x++)
  {
    MATRIX4& rotation = rotations[x];
    MATRIX4& scaling = scalings[x];
    VEC4& translation = translations[x];

    // get the endpoints of the cylinder
    VEC4 leftVertex(0,0,0,1);
    VEC4 rightVertex(0,0,lengths[x],1);

    leftVertex = rotation * scaling * leftVertex + translation;
    rightVertex = rotation * scaling * rightVertex + translation;

  





    // get the direction vector
    VEC3 direction = (rightVertex - leftVertex).head<3>();
    const float magnitude = direction.norm();
    direction *= 1.0 / magnitude;







    // how many spheres?
    const float sphereRadius = 0.05;
    const int totalSpheres = magnitude / (2.0 * sphereRadius);
    const float rayIncrement = magnitude / (float)totalSpheres;

    // store the spheres

    // sphere sphereList[x][totalSpheres+2];
    // sphereList[0].center = leftVertex.head<3>();
    // sphereList[0].radius = 0.05;
    // sphereList[0].color = VEC3(1,0,0);
    // sphereList[0].mirror = false;
    // sphereList[0].refraction = false;
    // sphereList[0].triangle = false;
    // sphereList[0].vertex1 = VEC3(INFINITY, INFINITY, INFINITY);
    // sphereList[0].vertex2 = VEC3(INFINITY, INFINITY, INFINITY);
    // sphereList[0].vertex3 = VEC3(INFINITY, INFINITY, INFINITY);

    // sphereLIst[1].center = rightVertex.head<3>();
    // sphereList[1].radius = 0.05;
    // sphereList[1].color = VEC3(1,0,0);
    // sphereList[1].mirror = false;
    // sphereList[1].refraction = false;
    // sphereList[1].triangle = false;
    // sphereList[1].vertex1 = VEC3(INFINITY, INFINITY, INFINITY);
    // sphereList[1].vertex2 = VEC3(INFINITY, INFINITY, INFINITY);
    // sphereList[1].vertex3 = VEC3(INFINITY, INFINITY, INFINITY);

    // for (int y = 0, int i = 2; y < totalSpheres; y++, i++)
    // {
    //   VEC3 center = ((float)y + 0.5) * rayIncrement * direction + leftVertex.head<3>();
      
      
    //   sphereList[i].center = center
    //   sphereList[i].radius = 0.05;
    //   sphereList[i].color = VEC3(1,0,0);
    //   sphereList[i].mirror = false;
    //   sphereList[i].refraction = false;
    //   sphereList[i].triangle = false;
    //   sphereList[i].vertex1 = VEC3(INFINITY, INFINITY, INFINITY);
    //   sphereList[i].vertex2 = VEC3(INFINITY, INFINITY, INFINITY);
    //   sphereList[i].vertex3 = VEC3(INFINITY, INFINITY, INFINITY);
    // }


    // sphereCenters.push_back(leftVertex.head<3>());
    // // cout << sphereCenters[0] << endl;
    // // exit(0);
    // sphereRadii.push_back(0.05);
    // sphereColors.push_back(VEC3(1,0,0));
    // mirror.push_back(false);
    // reflection.push_back(false);
    // refraction.push_back(false);
    // triangle.push_back(false);
    // vertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // vertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // vertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    

    // sphereCenters.push_back(rightVertex.head<3>());
    // sphereRadii.push_back(0.05);
    // sphereColors.push_back(VEC3(1,0,0));
    // mirror.push_back(false);
    // reflection.push_back(false);
    // refraction.push_back(false);
    // triangle.push_back(false);
    // vertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // vertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // vertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    
    
//      vector<VEC3> cylinderCenters;
//     vector<float> radiusCylinder;
//     vector<MATRIX4> cylinderRotation;
//     vector<VEC3> cylinderColors;
// vector<float> top;
// vector<float> bottom;

    

    shape.push_back(true);
    cylinder.push_back(true);
    triangle.push_back(false);
    sphere.push_back(false);
    cylinderCenters.push_back((truncate(rightVertex+leftVertex)/2.0)+VEC3(0, 0, 3));
    radiusCylinder.push_back(0.01);
    cylinderRotation.push_back(rotation);
    cylinderColors.push_back(VEC3(0.0, 0.6, 0.6));
    top.push_back(lengths[x]/2.0);
    bottom.push_back(-lengths[x]/2.0);
    triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
    sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    sphereRadii.push_back(-1);
    sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));   
    poleflag.push_back(false);  
    mirror.push_back(false);


    












    

    // translation = center;
    // rotation = rotation;
    // top = lengths[x]/2;
    // bottom = - lengths[x]/2;
    // radius = 0.05;
    // center = (rightVertex+leftVertex)/2;

    // adjustedcenterfornormal = center;
    // adjustedcenterfornormal[2] = center[2]+(pt[2]-center[2]);
    // normal = (pt-(center+())





    // for (int y = 0; y < totalSpheres; y++)
    // {
    //   VEC3 center = ((float)y + 0.5) * rayIncrement * direction + leftVertex.head<3>();
    //   sphereCenters.push_back(center);
    //   sphereRadii.push_back(0.05);
    //   sphereColors.push_back(VEC3(1,0,0));
    //   mirror.push_back(false);
    //   reflection.push_back(false);
    //   refraction.push_back(false);
    //   triangle.push_back(false);
    //   vertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    //   vertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    //   vertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // } 
  }

  MATRIX4 zeromatrix;
    zeromatrix << 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 
    
  // for(int i = 0; i<100; i++){

    //gray triangle
    shape.push_back(true);
    cylinder.push_back(false);
    triangle.push_back(true);
    sphere.push_back(false);
    cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    radiusCylinder.push_back(0.01);
    cylinderRotation.push_back(zeromatrix); //?
    cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
    top.push_back(-1.0);
    bottom.push_back(-1.0);
    // triangleVertex1.push_back(VEC3(-2, 0, 1));
    // triangleVertex2.push_back(VEC3(100, 0, 3));
    // triangleVertex3.push_back(VEC3(5, 0, 5));

    //old really big platform
    // triangleVertex1.push_back(VEC3(-1000, 0, -1));
    // triangleVertex2.push_back(VEC3(10000, 0, -1));
    // triangleVertex3.push_back(VEC3(0, 0, 1000));

    // triangleVertex1.push_back(VEC3(1, 0, 0));
    // triangleVertex2.push_back(VEC3(0, 0, 0));
    // triangleVertex3.push_back(VEC3(0, 0, 1));

    triangleVertex1.push_back(VEC3(1, 0, 0));
    triangleVertex2.push_back(VEC3(0, 0, 0));
    triangleVertex3.push_back(VEC3(0, 0, 1));

    // triangleColors.push_back(VEC3(0.5, 0.5, 0.5)); //gray
    triangleColors.push_back(VEC3(1, 1, 0)); //yellow
    // triangleColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
    // triangleColors.push_back(VEC3(168.0/255.0,147.0/255.0,111.0/255.0)); // weird brown trying to match picture- not working
    sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    sphereRadii.push_back(-1);
    sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    poleflag.push_back(false);  
    mirror.push_back(false);




    //not original gray triangle
    shape.push_back(true);
    cylinder.push_back(false);
    triangle.push_back(true);
    sphere.push_back(false);
    cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    radiusCylinder.push_back(0.01);
    cylinderRotation.push_back(zeromatrix); //?
    cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
    top.push_back(-1.0);
    bottom.push_back(-1.0);
    triangleVertex1.push_back(VEC3(1, 0, 0));
    triangleVertex2.push_back(VEC3(1, 0, 1));
    triangleVertex3.push_back(VEC3(0, 0, 1));
    triangleColors.push_back(VEC3(1, 1, 0)); //yellow
    // triangleColors.push_back(VEC3(0.5, 0.5, 0.5)); //gray
    // triangleColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
    // triangleColors.push_back(VEC3(168.0/255.0,147.0/255.0,111.0/255.0)); // weird brown trying to match picture- not working
    sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    sphereRadii.push_back(-1);
    sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    poleflag.push_back(false);  
    mirror.push_back(false);


    VEC3 backwardsoriginaltriangle1vertex1 = VEC3(1, 0, 0);
    VEC3 backwardsoriginaltriangle1vertex2 = VEC3(0, 0, 0);
    VEC3 backwardsoriginaltriangle1vertex3 = VEC3(0, 0, 1);

    VEC3 backwardsoriginaltriangle2vertex1 = VEC3(1, 0, 0);
    VEC3 backwardsoriginaltriangle2vertex2 = VEC3(1, 0, 1);
    VEC3 backwardsoriginaltriangle2vertex3 = VEC3(0, 0, 1);

    
    
    VEC3 originaltriangle1vertex1 = VEC3(1, 0, 0);
    VEC3 originaltriangle1vertex2 = VEC3(0, 0, 0);
    VEC3 originaltriangle1vertex3 = VEC3(0, 0, 1);

    VEC3 originaltriangle2vertex1 = VEC3(1, 0, 0);
    VEC3 originaltriangle2vertex2 = VEC3(1, 0, 1);
    VEC3 originaltriangle2vertex3 = VEC3(0, 0, 1);



    VEC3 originaloriginaltriangle1vertex1 = VEC3(1, 0, 0);
    VEC3 originaloriginaltriangle1vertex2 = VEC3(0, 0, 0);
    VEC3 originaloriginaltriangle1vertex3 = VEC3(0, 0, 1);

    VEC3 originaloriginaltriangle2vertex1 = VEC3(1, 0, 0);
    VEC3 originaloriginaltriangle2vertex2 = VEC3(1, 0, 1);
    VEC3 originaloriginaltriangle2vertex3 = VEC3(0, 0, 1);






    
    
    
    
    
    
    
    
    
    for(int rows = 0; rows<5; rows++){
      if(rows !=0){
         backwardsoriginaltriangle1vertex1 = originaloriginaltriangle1vertex1 + VEC3(0, 0, rows);
         backwardsoriginaltriangle1vertex2 = originaloriginaltriangle1vertex2 + VEC3(0, 0, rows);
         backwardsoriginaltriangle1vertex3 = originaloriginaltriangle1vertex3 + VEC3(0, 0, rows);

        backwardsoriginaltriangle2vertex1 = originaloriginaltriangle2vertex1+ VEC3(0, 0, rows);
        backwardsoriginaltriangle2vertex2 = originaloriginaltriangle2vertex2 + VEC3(0, 0, rows);
        backwardsoriginaltriangle2vertex3 = originaloriginaltriangle2vertex3 + VEC3(0, 0, rows);

        
        
        originaltriangle1vertex1 = originaloriginaltriangle1vertex1 + VEC3(0, 0, rows);
        originaltriangle1vertex2 = originaloriginaltriangle1vertex2 + VEC3(0, 0, rows);
        originaltriangle1vertex3 = originaloriginaltriangle1vertex3 + VEC3(0, 0, rows);

         originaltriangle2vertex1 = originaloriginaltriangle2vertex1 + VEC3(0, 0, rows);
         originaltriangle2vertex2 = originaloriginaltriangle2vertex2+ VEC3(0, 0, rows);
        originaltriangle2vertex3 = originaloriginaltriangle2vertex3 + VEC3(0, 0, rows);
      
      

        shape.push_back(true);
      cylinder.push_back(false);
      triangle.push_back(true);
      sphere.push_back(false);
      cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
      radiusCylinder.push_back(0.01);
      cylinderRotation.push_back(zeromatrix); //?
      cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
      top.push_back(-1.0);
      bottom.push_back(-1.0);
      // triangleVertex1.push_back(VEC3(-2, 0, 1));
      // triangleVertex2.push_back(VEC3(100, 0, 3));
      // triangleVertex3.push_back(VEC3(5, 0, 5));

      //old really big platform
      // triangleVertex1.push_back(VEC3(-1000, 0, -1));
      // triangleVertex2.push_back(VEC3(10000, 0, -1));
      // triangleVertex3.push_back(VEC3(0, 0, 1000));

      triangleVertex1.push_back(originaltriangle1vertex1);
      triangleVertex2.push_back(originaltriangle1vertex2);
      triangleVertex3.push_back(originaltriangle1vertex3);

      triangleColors.push_back(VEC3(0.5, 0.5, 0.5)); //gray
      // triangleColors.push_back(VEC3(1, 1, 0)); //yellow
      // triangleColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
      // triangleColors.push_back(VEC3(168.0/255.0,147.0/255.0,111.0/255.0)); // weird brown trying to match picture- not working
      sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
      sphereRadii.push_back(-1);
      sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
      poleflag.push_back(false);  
      mirror.push_back(false);




      //not original gray triangle
      shape.push_back(true);
      cylinder.push_back(false);
      triangle.push_back(true);
      sphere.push_back(false);
      cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
      radiusCylinder.push_back(0.01);
      cylinderRotation.push_back(zeromatrix); //?
      cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
      top.push_back(-1.0);
      bottom.push_back(-1.0);
      triangleVertex1.push_back(originaltriangle2vertex1);
      triangleVertex2.push_back(originaltriangle2vertex2);
      triangleVertex3.push_back(originaltriangle2vertex3);
      // triangleColors.push_back(VEC3(1, 1, 0)); //yellow
      triangleColors.push_back(VEC3(0.5, 0.5, 0.5)); //gray
      // triangleColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
      // triangleColors.push_back(VEC3(168.0/255.0,147.0/255.0,111.0/255.0)); // weird brown trying to match picture- not working
      sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
      sphereRadii.push_back(-1);
      sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
      poleflag.push_back(false); 
      mirror.push_back(false);
      
      
      
      
      
      
      
      
      }


      


    

    for(int i = 0; i <2; i++){ // before it was i<50
        //triangle 1 (left half of tile)
        
        originaltriangle1vertex1 = originaltriangle1vertex1 + VEC3(1,0,0);
        originaltriangle1vertex2 = originaltriangle1vertex2 + VEC3(1,0,0);
        originaltriangle1vertex3 = originaltriangle1vertex3 + VEC3(1,0,0);

        originaltriangle2vertex1 = originaltriangle2vertex1 + VEC3(1,0,0);
        originaltriangle2vertex2 = originaltriangle2vertex2 + VEC3(1,0,0);
        originaltriangle2vertex3 = originaltriangle2vertex3 + VEC3(1,0,0);


        shape.push_back(true);
        cylinder.push_back(false);
        triangle.push_back(true);
        sphere.push_back(false);
        cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        radiusCylinder.push_back(0.01);
        cylinderRotation.push_back(zeromatrix); //?
        cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
        top.push_back(-1.0);
        bottom.push_back(-1.0);

        triangleVertex1.push_back(originaltriangle1vertex1);
        triangleVertex2.push_back(originaltriangle1vertex2);
        triangleVertex3.push_back(originaltriangle1vertex3);


        if(rows == 0){
           triangleColors.push_back(VEC3(1, 1, 0)); //yellow
        }
        else{
          triangleColors.push_back(VEC3(0.5, 0.5, 0.5)); //gray
        }
       





        sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        sphereRadii.push_back(-1);
        sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        poleflag.push_back(false);  
        mirror.push_back(false);




        //triangle 2 (right half of tile)
        //i also made triangle 2 pink
        shape.push_back(true);
        cylinder.push_back(false);
        triangle.push_back(true);
        sphere.push_back(false);
        cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        radiusCylinder.push_back(0.01);
        cylinderRotation.push_back(zeromatrix); //?
        cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
        top.push_back(-1.0);
        bottom.push_back(-1.0);

        triangleVertex1.push_back(originaltriangle2vertex1);
        triangleVertex2.push_back(originaltriangle2vertex2);
        triangleVertex3.push_back(originaltriangle2vertex3);

        if(rows == 0){
           triangleColors.push_back(VEC3(1, 1, 0)); //yellow
        }
        else{
          triangleColors.push_back(VEC3(0.5, 0.5, 0.5)); //gray
        }



        sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        sphereRadii.push_back(-1);
        sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        poleflag.push_back(false); 
        mirror.push_back(false); 
    }


    
    

    for(int i = 0; i <5; i++){
        //triangle 1 (left half of tile)
        backwardsoriginaltriangle1vertex1 = backwardsoriginaltriangle1vertex1 - VEC3(1,0,0);
        backwardsoriginaltriangle1vertex2 = backwardsoriginaltriangle1vertex2 - VEC3(1,0,0);
        backwardsoriginaltriangle1vertex3 = backwardsoriginaltriangle1vertex3 - VEC3(1,0,0);

        backwardsoriginaltriangle2vertex1 = backwardsoriginaltriangle2vertex1 - VEC3(1,0,0);
        backwardsoriginaltriangle2vertex2 = backwardsoriginaltriangle2vertex2 - VEC3(1,0,0);
        backwardsoriginaltriangle2vertex3 = backwardsoriginaltriangle2vertex3 - VEC3(1,0,0);






        shape.push_back(true);
        cylinder.push_back(false);
        triangle.push_back(true);
        sphere.push_back(false);
        cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        radiusCylinder.push_back(0.01);
        cylinderRotation.push_back(zeromatrix); //?
        cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
        top.push_back(-1.0);
        bottom.push_back(-1.0);

        triangleVertex1.push_back(backwardsoriginaltriangle1vertex1);
        triangleVertex2.push_back(backwardsoriginaltriangle1vertex2);
        triangleVertex3.push_back(backwardsoriginaltriangle1vertex3);

        if(rows == 0){
           triangleColors.push_back(VEC3(1, 1, 0)); //yellow
        }
        else{
          triangleColors.push_back(VEC3(0.5, 0.5, 0.5)); //gray
        }



        sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        sphereRadii.push_back(-1);
        sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        poleflag.push_back(false);  
        mirror.push_back(false);




        //triangle 2 (right half of tile)
        //i also made triangle 2 pink
        shape.push_back(true);
        cylinder.push_back(false);
        triangle.push_back(true);
        sphere.push_back(false);
        cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        radiusCylinder.push_back(0.01);
        cylinderRotation.push_back(zeromatrix); //?
        cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
        top.push_back(-1.0);
        bottom.push_back(-1.0);

        triangleVertex1.push_back(backwardsoriginaltriangle2vertex1);
        triangleVertex2.push_back(backwardsoriginaltriangle2vertex2);
        triangleVertex3.push_back(backwardsoriginaltriangle2vertex3);

        if(rows == 0){
           triangleColors.push_back(VEC3(1, 1, 0)); //yellow
        }
        else{
          triangleColors.push_back(VEC3(0.5, 0.5, 0.5)); //gray
        }





        sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        sphereRadii.push_back(-1);
        sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
        poleflag.push_back(false);  
        mirror.push_back(false);
    }
    }




    // //wall or sign?
    // shape.push_back(true);
    // cylinder.push_back(false);
    // triangle.push_back(true);
    // sphere.push_back(false);
    // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // radiusCylinder.push_back(-1);
    // cylinderRotation.push_back(zeromatrix); //?
    // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
    // top.push_back(INFINITY);
    // bottom.push_back(-INFINITY);
    // // triangleVertex1.push_back(VEC3(-2, 0, 1));
    // // triangleVertex2.push_back(VEC3(100, 0, 3));
    // // triangleVertex3.push_back(VEC3(5, 0, 5));
    // triangleVertex1.push_back(VEC3(-1000, 0, -1));
    // triangleVertex2.push_back(VEC3(10000, 0, -1));
    // triangleVertex3.push_back(VEC3(0, 0, 1000));
    // triangleColors.push_back(VEC3(1.0, 1.0, 0.5));
    // // triangleColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
    // // triangleColors.push_back(VEC3(168.0/255.0,147.0/255.0,111.0/255.0)); // weird brown trying to match picture- not working
    // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // sphereRadii.push_back(-1);
    // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // poleflag.push_back(false); 






    // shape.push_back(true);
    // cylinder.push_back(false);
    // triangle.push_back(true);
    // sphere.push_back(false);
    // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // radiusCylinder.push_back(0.01);
    // cylinderRotation.push_back(zeromatrix); //?
    // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
    // top.push_back(-1.0);
    // bottom.push_back(-1.0);
    // // triangleVertex1.push_back(VEC3(-2, 0, 1));
    // // triangleVertex2.push_back(VEC3(100, 0, 3));
    // // triangleVertex3.push_back(VEC3(5, 0, 5));
    // triangleVertex1.push_back(VEC3(-1000, 200, -1));
    // triangleVertex2.push_back(VEC3(10000, 200, -1));
    // triangleVertex3.push_back(VEC3(0, 200, 1000));
    // triangleColors.push_back(VEC3(0.5, 0.5, 0.5));
    // // triangleColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
    // // triangleColors.push_back(VEC3(168.0/255.0,147.0/255.0,111.0/255.0)); // weird brown trying to match picture- not working
    // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // sphereRadii.push_back(-1);
    // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // poleflag.push_back(false);   


  // }


    // shape.push_back(true);
    // cylinder.push_back(false);
    // triangle.push_back(true);
    // sphere.push_back(false);
    // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // radiusCylinder.push_back(0.01);
    // cylinderRotation.push_back(zeromatrix); //?
    // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
    // top.push_back(-1.0);
    // bottom.push_back(-1.0);
    // // triangleVertex1.push_back(VEC3(-2, 0, 1));
    // // triangleVertex2.push_back(VEC3(100, 0, 3));
    // // triangleVertex3.push_back(VEC3(5, 0, 5));
    // triangleVertex1.push_back(VEC3(500, 0, 0));
    // triangleVertex2.push_back(VEC3(0, 0, 2));
    // triangleVertex3.push_back(VEC3(0, 0, 1));
    // triangleColors.push_back(VEC3(1, 0.0, 1));
    // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // sphereRadii.push_back(-1);
    // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));   

    // shape.push_back(true);
    // cylinder.push_back(false);
    // triangle.push_back(true);
    // sphere.push_back(false);
    // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // radiusCylinder.push_back(0.01);
    // cylinderRotation.push_back(zeromatrix); //?
    // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
    // top.push_back(-1.0);
    // bottom.push_back(-1.0);
    // // triangleVertex1.push_back(VEC3(-2, 0, 1));
    // // triangleVertex2.push_back(VEC3(100, 0, 3));
    // // triangleVertex3.push_back(VEC3(5, 0, 5));
    // triangleVertex1.push_back(VEC3(-2, 0, 1));
    // triangleVertex2.push_back(VEC3(0, 0, 2));
    // triangleVertex3.push_back(VEC3(0, 0, 1));
    // triangleColors.push_back(VEC3(1, 1.0, 0));
    // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // sphereRadii.push_back(-1);
    // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));   


  MATRIX4 identitymatrix;
  identitymatrix<< 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 ;

  // // MATRIX4 scalingpole;
  // // scalingpole = identitymatrix;


  double theta = (90.0/180.0)*PI;

  MATRIX4 rotatepoles;
  rotatepoles << 1, 0, 0, 0, 0, cos(theta), -sin(theta), 0, 0, sin(theta), cos(theta), 0, 0, 0, 0, 1;

  // MATRIX4 translatepole;
  // translatepole << 1, 0, 0, 5, 
  //                 0, 1, 0, 0, 
  //                 0, 0, 1, 2,
  //                 0, 0, 0, 1;


  // VEC4 leftVertex(0,0,0,1);
  // VEC4 rightVertex(0,0,20,1);

  // leftVertex = rotation * scalingpole * leftVertex + translation;
  // rightVertex = rotation * scalingpole * rightVertex + translation;






  // rotate on x?
  //pole
  shape.push_back(true);
  cylinder.push_back(true);
  triangle.push_back(false);
  sphere.push_back(false);
  cylinderCenters.push_back(VEC3(-2, 5, 1.5));
  radiusCylinder.push_back(0.25); //used to be 0.75- should prob be same width
  cylinderRotation.push_back(rotatepoles); //?
  cylinderColors.push_back(VEC3(112.0/255.0, 50.0/255.0, 41.0/255.0));
  // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  top.push_back(5.0);
  bottom.push_back(-5.0);
  triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  sphereRadii.push_back(-1);
  sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  poleflag.push_back(false);
  mirror.push_back(false);



  // shape.push_back(true);
  // cylinder.push_back(true);
  // triangle.push_back(false);
  // sphere.push_back(false);
  // cylinderCenters.push_back(VEC3(2, 10, 1.5));
  // radiusCylinder.push_back(0.25); //used to be 0.75- should prob be same width
  // cylinderRotation.push_back(rotatepoles); //?
  // cylinderColors.push_back(VEC3(112.0/255.0, 50.0/255.0, 41.0/255.0));
  // // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  // // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  // top.push_back(10.0);
  // bottom.push_back(-10.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // sphereRadii.push_back(-1);
  // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  // poleflag.push_back(false);

  VEC3 originalcenterofpole = VEC3(-2, 5, 1.5);


  for(int i =0; i<1; i++){

    originalcenterofpole = originalcenterofpole + VEC3(4,0,0);

    shape.push_back(true);
    cylinder.push_back(true);
    triangle.push_back(false);
    sphere.push_back(false);
    cylinderCenters.push_back(originalcenterofpole);
    radiusCylinder.push_back(0.25); //used to be 0.75- should prob be same width
    cylinderRotation.push_back(rotatepoles); //?
    cylinderColors.push_back(VEC3(112.0/255.0, 50.0/255.0, 41.0/255.0));
    // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
    // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
    top.push_back(5.0); //10 before
    bottom.push_back(-5.0);//-10 before
    triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
    sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    sphereRadii.push_back(-1);
    sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
    poleflag.push_back(false);
    mirror.push_back(false);
  }

  // shape.push_back(true);
  // cylinder.push_back(true);
  // triangle.push_back(false);
  // sphere.push_back(false);
  // cylinderCenters.push_back(VEC3(-4, 10, 0));
  // radiusCylinder.push_back(0.25);
  // cylinderRotation.push_back(rotatepoles); //?
  // // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  // cylinderColors.push_back(VEC3(112.0/255.0, 50.0/255.0, 41.0/255.0));
  // // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  // top.push_back(10.0);
  // bottom.push_back(-10.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // sphereRadii.push_back(-1);
  // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  // poleflag.push_back(false);







  //SPHERES START HERE?

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(5, 0, 2));
  // radiusCylinder.push_back(0.05);
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(0.5, 0.5, 0.5));
  // top.push_back(1000);
  // bottom.push_back(-100.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(0,0.5,0));
  // sphereRadii.push_back(0.1);
  // sphereColors.push_back(VEC3(1, 0, 0));  
  // poleflag.push_back(false);
  // mirror.push_back(false);

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(5, 0, 2));
  // radiusCylinder.push_back(0.05);
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(0.5, 0.5, 0.5));
  // top.push_back(1000);
  // bottom.push_back(-100.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(2, 0, 0));
  // sphereRadii.push_back(0.1);
  // sphereColors.push_back(VEC3(1, 0, 0));  
  // poleflag.push_back(false);

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(5, 0, 2));
  // radiusCylinder.push_back(0.05);
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(0.5, 0.5, 0.5));
  // top.push_back(1000);
  // bottom.push_back(-100.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(-1, 0, 0));
  // sphereRadii.push_back(0.1);
  // sphereColors.push_back(VEC3(1, 0, 0));  
  // poleflag.push_back(false);

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(5, 0, 2));
  // radiusCylinder.push_back(0.05);
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(0.5, 0.5, 0.5));
  // top.push_back(1000);
  // bottom.push_back(-100.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(-2, 0, 0));
  // sphereRadii.push_back(0.1);
  // sphereColors.push_back(VEC3(1, 0, 0));  
  // poleflag.push_back(false);

  
  


  // // y-axis
  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(0.01);
  // cylinderRotation.push_back(zeromatrix); //?
  // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
  // top.push_back(-1.0);
  // bottom.push_back(-1.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(0, 1, 0));
  // sphereRadii.push_back(.05);
  // sphereColors.push_back(VEC3(0, 1, 0));
  // poleflag.push_back(false);

  //  shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(0.01);
  // cylinderRotation.push_back(zeromatrix); //?
  // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
  // top.push_back(-1.0);
  // bottom.push_back(-1.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(0, 2, 0));
  // sphereRadii.push_back(.05);
  // sphereColors.push_back(VEC3(0, 1, 0));
  // poleflag.push_back(false);


  // //z-axis

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(0.01);
  // cylinderRotation.push_back(zeromatrix); //?
  // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
  // top.push_back(-1.0);
  // bottom.push_back(-1.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(0, 0, -2));
  // sphereRadii.push_back(.05);
  // sphereColors.push_back(VEC3(0, 0, 1));
  // poleflag.push_back(false);



  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(0.01);
  // cylinderRotation.push_back(zeromatrix); //?
  // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
  // top.push_back(-1.0);
  // bottom.push_back(-1.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(0, 0, -1));
  // sphereRadii.push_back(.05);
  // sphereColors.push_back(VEC3(0, 0, 1));
  // poleflag.push_back(false);



  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(0.01);
  // cylinderRotation.push_back(zeromatrix); //?
  // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
  // top.push_back(-1.0);
  // bottom.push_back(-1.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(0, 0, 1));
  // sphereRadii.push_back(.05);
  // sphereColors.push_back(VEC3(0, 0, 1));
  // poleflag.push_back(false);

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(0.01);
  // cylinderRotation.push_back(zeromatrix); //?
  // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
  // top.push_back(-1.0);
  // bottom.push_back(-1.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(0, 0, 2));
  // sphereRadii.push_back(.05);
  // sphereColors.push_back(VEC3(0, 0, 1));
  // poleflag.push_back(false);





  // //origin
  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(0.01);
  // cylinderRotation.push_back(zeromatrix); //?
  // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
  // top.push_back(-1.0);
  // bottom.push_back(-1.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(0, 0, 0));
  // sphereRadii.push_back(.05);
  // sphereColors.push_back(VEC3(0, 0, 0));
  // poleflag.push_back(false);


  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(false);
  // sphere.push_back(true);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(0.01);
  // cylinderRotation.push_back(zeromatrix); //?
  // cylinderColors.push_back(VEC3(1.0, 1.0, 1.0));
  // top.push_back(-1.0);
  // bottom.push_back(-1.0);
  // triangleVertex1.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex2.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleVertex3.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // triangleColors.push_back(VEC3(1.0, 1.0, 1.0));
  // sphereCenters.push_back(VEC3(2, 0, 1.5));
  // sphereRadii.push_back(.05);
  // sphereColors.push_back(VEC3(1.0, 0, 1.0));
  // poleflag.push_back(false);




  //wall  
  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(true) g;
  // sphere.push_back(false);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(-1); //used to be 0.75- should prob be same width
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  //   // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  //   // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  // top.push_back(10.0);
  // bottom.push_back(-10.0);
  // triangleVertex1.push_back(VEC3(50,0,50));
  // triangleVertex2.push_back(VEC3(-50,0,50));
  // triangleVertex3.push_back(VEC3(-50,50,50));
  // triangleColors.push_back(VEC3(1,0, 1));
  // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // sphereRadii.push_back(-1);
  // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  // poleflag.push_back(false);
  // mirror.push_back(true);

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(true);
  // sphere.push_back(false);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(-1); //used to be 0.75- should prob be same width
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  //   // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  //   // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  // top.push_back(10.0);
  // bottom.push_back(-10.0);
  // triangleVertex1.push_back(VEC3(50,0,50));
  // triangleVertex2.push_back(VEC3(50,50,50));
  // triangleVertex3.push_back(VEC3(-50,50,50));
  // triangleColors.push_back(VEC3(1,0, 1));
  // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // sphereRadii.push_back(-1);
  // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  // poleflag.push_back(false);
  // mirror.push_back(true);




//TRUE MIRRORS HERE


  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(true);
  // sphere.push_back(false);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(-1); //used to be 0.75- should prob be same width
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  //   // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  //   // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  // top.push_back(10.0);
  // bottom.push_back(-10.0);
  // triangleVertex1.push_back(VEC3(50,0,-0.5));
  // triangleVertex2.push_back(VEC3(-50,0, -0.5));
  // triangleVertex3.push_back(VEC3(-50,50,-0.5));
  // triangleColors.push_back(VEC3(1,0, 1));
  // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // sphereRadii.push_back(-1);
  // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  // poleflag.push_back(false);
  // mirror.push_back(true);

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(true);
  // sphere.push_back(false);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(-1); //used to be 0.75- should prob be same width
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  //   // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  //   // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  // top.push_back(10.0);
  // bottom.push_back(-10.0);
  // triangleVertex1.push_back(VEC3(50,0,-0.5));
  // triangleVertex2.push_back(VEC3(50,50,-0.5));
  // triangleVertex3.push_back(VEC3(-50,50,-0.5));
  // triangleColors.push_back(VEC3(1,0, 1));
  // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // sphereRadii.push_back(-1);
  // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  // poleflag.push_back(false);
  // mirror.push_back(true);


  //weird puddle

  shape.push_back(true);
  cylinder.push_back(false);
  triangle.push_back(true);
  sphere.push_back(false);
  cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  radiusCylinder.push_back(-1); //used to be 0.75- should prob be same width
  cylinderRotation.push_back(identitymatrix); //?
  cylinderColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
    // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  top.push_back(10.0);
  bottom.push_back(-10.0);
  triangleVertex1.push_back(VEC3(-1.5,0.01, 2));
  triangleVertex2.push_back(VEC3(0.5,0.01, 3));
  triangleVertex3.push_back(VEC3(-1.5,0.01,4));
  triangleColors.push_back(VEC3(1,0, 1));
  sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  sphereRadii.push_back(-1);
  sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  poleflag.push_back(false);
  mirror.push_back(true);


  shape.push_back(true);
  cylinder.push_back(false);
  triangle.push_back(false);
  sphere.push_back(true);
  cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  radiusCylinder.push_back(-1); //used to be 0.75- should prob be same width
  cylinderRotation.push_back(identitymatrix); //?
  cylinderColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
    // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
    // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  top.push_back(10.0);
  bottom.push_back(-10.0);
  triangleVertex1.push_back(VEC3(0,1, 1));
  triangleVertex2.push_back(VEC3(0,1, 1));
  triangleVertex3.push_back(VEC3(0,1,1));
  triangleColors.push_back(VEC3(1,1, 0));
  sphereCenters.push_back(VEC3(0.1, 0.1, 3));
  sphereRadii.push_back(0.1);
  sphereColors.push_back(VEC3(1, 1, 0));  
  poleflag.push_back(false);
  mirror.push_back(false);


  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(true);
  // sphere.push_back(false);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(-1); //used to be 0.75- should prob be same width
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  //   // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  //   // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  // top.push_back(10.0);
  // bottom.push_back(-10.0);
  // triangleVertex1.push_back(VEC3(5,0.01,5));
  // triangleVertex2.push_back(VEC3(-5,0.01, 5));
  // triangleVertex3.push_back(VEC3(-5,10,5));
  // triangleColors.push_back(VEC3(1,0, 1));
  // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // sphereRadii.push_back(-1);
  // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  // poleflag.push_back(false);
  // mirror.push_back(false);

  // shape.push_back(true);
  // cylinder.push_back(false);
  // triangle.push_back(true);
  // sphere.push_back(false);
  // cylinderCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // radiusCylinder.push_back(-1); //used to be 0.75- should prob be same width
  // cylinderRotation.push_back(identitymatrix); //?
  // cylinderColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  //   // cylinderColors.push_back(VEC3(1.0, 0.0, 0.0));
  //   // cylinderColors.push_back(VEC3(0.75294117647, 0.75294117647, 0.75294117647));
  // top.push_back(10.0);
  // bottom.push_back(-10.0);
  // triangleVertex1.push_back(VEC3(5,0.01,5));
  // triangleVertex2.push_back(VEC3(5,10,5));
  // triangleVertex3.push_back(VEC3(-5,10,5));
  // triangleColors.push_back(VEC3(1,0, 1));
  // sphereCenters.push_back(VEC3(INFINITY, INFINITY, INFINITY));
  // sphereRadii.push_back(-1);
  // sphereColors.push_back(VEC3(INFINITY, INFINITY, INFINITY));  
  // poleflag.push_back(false);
  // mirror.push_back(false);




}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
  string skeletonFilename("breakdance individual.asf");
  string motionFilename("85_14.amc");
  // string skeletonFilename("01.asf");
  // string motionFilename("01_02.amc");
  // string skeletonFilename("02.asf");
  // string motionFilename("02_05.amc");
  
  // load up skeleton stuff
  skeleton = new Skeleton(skeletonFilename.c_str(), MOCAP_SCALE);
  skeleton->setBasePosture();
  displayer.LoadSkeleton(skeleton);

  // load up the motion
  motion = new Motion(motionFilename.c_str(), MOCAP_SCALE, skeleton);
  displayer.LoadMotion(motion);
  skeleton->setPosture(*(displayer.GetSkeletonMotion(0)->GetPosture(0)));

  int numofeyeshifts = 0;

  // Note we're going 8 frames at a time, otherwise the animation
  // is really slow.
  for (int x = 0; x < 2400; x += 8)
  {
    
    // printf("here\n");
    if(x>416 && numofeyeshifts<5*30){ //goes from VEC3(0, 0.5, -5) to VEC3(-5, 0.5, 2)
      eye[0] = eye[0]-1.0*(1.0/30.0);
      eye[2] = eye[2]+1.4*(1.0/30.0);
      numofeyeshifts++;
      // printf("here\n");
    }
    if(x!=216*8){
      continue;
    }

    // cout << eye << endl;

    // they eye is pointing to where the train would be
    // eye = VEC3(0, 1, 6);




    // if(x > 208 && numofeyeshifts <149){ //goes from VEC3(0.0, 0.5, -7) to VEC3(-6, 0.5, 0.98)
    //   eye[0] = eye[0]-.010*4;
    //   eye[2] = eye[2]+.0133*4;
    //   numofeyeshifts++;
    //   // printf("here\n");
    // }



    // //NOTE: there is a weird part where camera gets too close to person before passing column

    // if(numofeyeshifts == 149){
    //   eye = VEC3(-6, 0.5, 1.0);
    // }

      // eye = VEC3(0.0, 0.5, -5);


    // if(numofeyeshifts>= 150){ // hopefully will go from VEC3(-6, 0.5, 0.98) to VEC3(0, 0.5, 5) 
    //   eye[0] = eye[0] + 1.00
    //   eye[2] = eye[2] + 
    // }
    // eye = VEC3(0, 0.5, 5); //eye to see sign but not poles

    //  eye = VEC3(3, 0.1, 10); //BADDDDD ANGLEEEEE
//       -6
//  0.5
// 0.98
    // cout << eye << endl;
// VEC3 eye(0.0, 0.5, -7);
//     eye[0] = eye[0]-1.0;

    // eye = VEC3(-5, 0.5, 2); //looks at person straight onnnn
    // eye = VEC3(0, 0.5, -5); //looks down z-axis


    setSkeletonsToSpecifiedFrame(x);
    buildScene();
    // if (x == 0){
    //   lookingAt = cylinderCenters[0] - VEC3(0, 0, 2);
    // }
    // lookingAt = VEC3(0,0.5,2); //what used before and worked?

    char buffer[256];
    sprintf(buffer, "./frames/frame.%04i.ppm", x / 8);
    renderImage(windowWidth, windowHeight, buffer);
    cout << "Rendered " + to_string(x / 8) + " frames" << endl;
  }

  return 0;
}
