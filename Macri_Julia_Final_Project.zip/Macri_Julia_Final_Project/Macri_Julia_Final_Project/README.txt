Title: Dancing in the Subway
Link: https://youtu.be/8rLM6vZwh28
Effects Implemented: glossy reflection (on triangle), soft shadows
Instructions on how to build and run code: copy files into Final Project starter code -> make -> run ./previz -> look at rendered frame in frames (216th frame)
